import tkinter as tk
from tkinter import ttk

window = tk.Tk()
window.title("Calculator")
window.maxsize(width=400, height=300)
window.minsize(width=300, height=100)
window.geometry("300x300")

frame1 = tk.Frame(window)
frame1.pack(side="top",fill="both",expand=True)

frame2 = tk.Frame(window)
frame2.pack(side="top",fill="both",expand=True)

frame3 = tk.Frame(window)
frame3.pack(side="top",fill="both",expand=True)

frame4 = tk.Frame(window)
frame4.pack(side="top",fill="both",expand=True)

frame5 = tk.Frame(window)
frame5.pack(side="top",fill="both",expand=True)

e = (tk.Entry(frame1,width=50,borderwidth=5,font=("Times New Roman",20)))
e.pack(fill="both",expand=True)

n1=""
n2=""
opt=""
res=0

def click(param):
    global n1,n2,opt,res
    if param=="clear":
        e.delete(0,tk.END)
        n1=""
        n2=""
        opt=""
        res=""
    else:
        l=["add","sub","mul","div"]
        if param in l:
            if n1=="":
                n1+=e.get()
            opt=param
            e.delete(0,tk.END)
        elif param == "calculate":
            n2=e.get()
            e.delete(0,tk.END)
            res=0
            if opt=="add":
                e.insert(tk.END,int(n1)+int(n2))
                res=int(n1)+int(n2)
            elif opt=="sub":
                e.insert(tk.END,int(n1)-int(n2))
                res = int(n1) - int(n2)
            elif opt=="mul":
                e.insert(tk.END,int(n1)*int(n2))
                res = int(n1) * int(n2)
            elif opt=="div":
                e.insert(tk.END,int(n1)/int(n2))
                res = int(n1) / int(n2)
            opt=""
            n1=str(res)
            n2=""
        else:
            e.insert(tk.END, param)

tk.Button(frame2,text="  1  ",width=8,command=lambda:click(1)).pack(side="left",fill="both",expand=True)
tk.Button(frame2,text="  2  ",width=8,command=lambda:click(2)).pack(side="left",fill="both",expand=True)
tk.Button(frame2,text="  3  ",width=8,command=lambda:click(3)).pack(side="left",fill="both",expand=True)
tk.Label(frame2,text="").pack(side="left",fill="both")
tk.Button(frame2,text="  + ",width=8,command=lambda:click("add")).pack(side="left",fill="both",expand=True)

tk.Button(frame3,text="  4  ",width=8,command=lambda:click(4)).pack(side="left",fill="both",expand=True)
tk.Button(frame3,text="  5  ",width=8,command=lambda:click(5)).pack(side="left",fill="both",expand=True)
tk.Button(frame3,text="  6  ",width=8,command=lambda:click(6)).pack(side="left",fill="both",expand=True)
tk.Label(frame3,text="").pack(side="left",fill="both")
tk.Button(frame3,text="  -  ",width=8,command=lambda:click("sub")).pack(side="left",fill="both",expand=True)

tk.Button(frame4,text="  7  ",width=8,command=lambda:click(7)).pack(side="left",fill="both",expand=True)
tk.Button(frame4,text="  8  ",width=8,command=lambda:click(8)).pack(side="left",fill="both",expand=True)
tk.Button(frame4,text="  9  ",width=8,command=lambda:click(9)).pack(side="left",fill="both",expand=True)
tk.Label(frame4,text="").pack(side="left",fill="both")
tk.Button(frame4,text="  *  ",width=8,command=lambda:click("mul")).pack(side="left",fill="both",expand=True)

tk.Button(frame5,text="Clear",width=8,command=lambda:click("clear")).pack(side="left",fill="both",expand=True)
tk.Button(frame5,text="  0  ",width=8,command=lambda:click(0)).pack(side="left",fill="both",expand=True)
tk.Button(frame5,text="  =  ",width=8,command=lambda:click("calculate")).pack(side="left",fill="both",expand=True)
tk.Label(frame5,text="").pack(side="left",fill="both")
tk.Button(frame5,text="  / ",width=8,command=lambda:click("div")).pack(side="left",fill="both",expand=True)

window.mainloop()